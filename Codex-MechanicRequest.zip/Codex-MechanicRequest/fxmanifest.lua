fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Codex-MechanicRequest'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}

server_scripts {
    'config.lua',
    'server.lua'
}

dependencies {
    'es_extended'
}
